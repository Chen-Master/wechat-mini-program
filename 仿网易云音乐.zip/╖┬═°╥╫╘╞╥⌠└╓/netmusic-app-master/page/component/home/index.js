var toplist=require("../../../utils/toplist.js");
Page({
    data:{},
    onLoad:function(){}
})